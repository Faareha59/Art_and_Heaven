<?php
// Connect to the database
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "art_heaven";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process purchase request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Read JSON input
    $data = json_decode(file_get_contents('php://input'), true);

    if ($data) {
        foreach ($data as $item) {
            $product_name = $item['product'];
            $price = $item['price'];
            $color = $item['selectedColor'];
            $size = $item['selectedSize'];
            $material = $item['selectedMaterial'];
            $quantity = $item['quantity'];

            // Insert data into purchases table
            $sql = "INSERT INTO purchases (product_name, price, color, size, material, quantity) 
                    VALUES ('$product_name', $price, '$color', '$size', '$material', $quantity)";

            if (!$conn->query($sql)) {
                echo "Error: " . $sql . "<br>" . $conn->error;
                exit;
            }
        }
        echo "Purchase successful!";
    } else {
        echo "No data received!";
    }
}

$conn->close();
?>
