'use strict';
// ?============= PRELOADER ===================== //


 const preloader = document.querySelector("[data-preloader]");

 window.addEventListener("load", function () {
   preloader.classList.add("loaded");
   document.body.classList.add("loaded");
 });

 function checkout() {
  if (cart.length === 0) {
      alert("Your cart is empty.");
      return;
  }

  fetch('checkout.php', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
      },
      body: JSON.stringify(cart),
  })
  .then(response => response.json())
  .then(data => {
      if (data.success) {
          alert("Purchase successful!");
          cart = [];
          updateCart();
      } else {
          alert("Purchase failed. Try again later.");
      }
  })
  .catch(error => {
      console.error('Error:', error);
      alert("An error occurred during checkout.");
  });
}

 //

// Add a click event listener to the button with the data-nav-toggler attribute
document.querySelector("[data-nav-toggler]").addEventListener("click", function() {
  const menuIcon = document.getElementById("menuIcon");
  // Toggle between classes
  menuIcon.classList.toggle("fa-bars");
  menuIcon.classList.toggle("fa-xmark");
});




// ?============= MOBILE NAV TOGGLE ===================== //

const navbar = document.querySelector("[data-navbar]");
const navToggler = document.querySelector("[data-nav-toggler]");

const toggleNavbar = function () { 
  navbar.classList.toggle("active"); 
}
navToggler.addEventListener("click", toggleNavbar);




// ?============= HEADER ===================== //
    // ?============= active header when window scrolled to 50px ===================== //

 const header = document.querySelector("[data-header]");

 const activeHeader = function () {
   window.scrollY > 50 ? header.classList.add("active")
     : header.classList.remove("active");
 }
 
 window.addEventListener("scroll", activeHeader);

 document.addEventListener('DOMContentLoaded', function() {
  const authorElement = document.getElementById('author');
  const authorText = '&copy; 2024 Copyright All Right Reserved By Tooba Baqai & Faareha Raza';
  authorElement.innerHTML = authorText;
});

