<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "art_heaven";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get cart data from the request
$cart = json_decode(file_get_contents('php://input'), true);
$response = ["success" => false];

if ($cart && is_array($cart)) {
    $stmt = $conn->prepare("INSERT INTO purchases (product_name, price, color, size, material, quantity) VALUES (?, ?, ?, ?, ?, ?)");

    foreach ($cart as $item) {
        $stmt->bind_param("sdsssi", $item['product'], $item['price'], $item['selectedColor'], $item['selectedSize'], $item['selectedMaterial'], $item['quantity']);
        $stmt->execute();
    }

    $stmt->close();
    $response["success"] = true;
}

echo json_encode($response);
$conn->close();
?>
