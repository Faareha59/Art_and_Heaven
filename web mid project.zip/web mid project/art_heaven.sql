-- Step 1: Create the Database

USE art_heaven;

-- Step 2: Create the Products Table (optional, if you want to store product details in the database)
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    image_url VARCHAR(255),
    description TEXT,
    color_options VARCHAR(255),  -- e.g., "Blue, Red, Green"
    size_options VARCHAR(255),   -- e.g., "Small, Big"
    material_options VARCHAR(255) -- e.g., "Ceramic, Clay"
);

-- Step 3: Insert Sample Data into Products Table (optional, for initial products display)
INSERT INTO products (name, price, image_url, description, color_options, size_options, material_options)
VALUES 
('Artistic Pottery 1', 40.00, 'images/0415a761c33f7aa8d45a768e349fad43.jpg', 'A beautiful piece of artistic pottery', 'Blue, Red, Green', 'Small, Big', 'Ceramic, Clay'),
('Artistic Pottery 2', 45.00, 'images/267fefddd30aebb7006e73c3b8d68ac8.jpg', 'Handcrafted pottery with a modern touch', 'Blue, Red, Green', 'Small, Big', 'Ceramic, Clay'),
('Artistic Pottery 3', 50.00, 'images/6998303_org.jpg', 'Elegant and durable pottery', 'Blue, Red, Green', 'Small, Big', 'Ceramic, Clay'),
('Artistic Pottery 4', 55.00, 'images/skill-banner.png', 'Unique and stylish pottery', 'Blue, Red, Green', 'Small, Big', 'Ceramic, Clay');

-- Step 4: Create the Purchases Table to Store Purchase Records
CREATE TABLE purchases (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    color VARCHAR(50),
    size VARCHAR(50),
    material VARCHAR(50),
    quantity INT NOT NULL,
    purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
